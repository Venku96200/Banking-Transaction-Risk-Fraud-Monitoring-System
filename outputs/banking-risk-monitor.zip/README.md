# Banking Transaction Risk Monitoring

An educational, synthetic-data risk-monitoring application. It combines transparent controls with an anomaly signal to prioritize transactions for human review. It is not an AML, fraud-detection, or compliance decision system.

## Included MVP

- FastAPI validation and transaction ingestion (single JSON transaction or CSV upload)
- SQLite persistence for customers, transactions, alerts, and analyst reviews
- Five explainable controls: amount deviation, new device, new location, unusual hour, and velocity
- Bounded hybrid score: `60% rules + 40% anomaly signal`, classified as Low/Medium/High/Critical
- Persistent High/Critical alert queue, reviews, false-positive outcomes, and escalation
- Browser dashboard with KPIs, distribution, trend, and analyst actions
- Reproducible generator for 50,000 synthetic transactions and an Isolation Forest training script

## Run locally

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`. API documentation is at `/docs`.

To create synthetic data and train the optional model:

```powershell
python data/generate_data.py
python ml/train.py
pytest
```

The API automatically uses the trained Isolation Forest when `ml/model.joblib` exists; before then it uses a calibrated transparent fallback score so the full app remains runnable.

## Quick API example

```powershell
$body = @{ transaction_id='TX-DEMO-001'; customer_id='C-DEMO'; timestamp='2026-08-13T02:15:00'; amount=85000; merchant_category='Travel'; location='Dubai'; device_id='D-NEW'; transaction_type='Transfer'; account_age_days=720 } | ConvertTo-Json
Invoke-RestMethod http://127.0.0.1:8000/transactions -Method Post -ContentType 'application/json' -Body $body
```

## Risk rules and limitations

The thresholds are illustrative, model-generated scores are not evidence of wrongdoing, and all dataset records are synthetic. A production version would need access controls, audit logging, model validation/monitoring, governance, privacy controls, and expert review.
